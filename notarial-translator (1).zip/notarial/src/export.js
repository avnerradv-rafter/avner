import { jsPDF } from 'jspdf'
import autoTable from 'jspdf-autotable'
import { Document, Packer, Paragraph, TextRun, Table, TableRow, TableCell,
         BorderStyle, AlignmentType, HeadingLevel, WidthType,
         ShadingType, PageOrientation, Header, Footer } from 'docx'
import { NOTARIAL_CERTIFICATION, NOTARY_BLOCK } from './constants.js'

// ─── PDF Export ───────────────────────────────────────────────────────────────

export async function exportToPDF(result, translatorName, date) {
  const doc = new jsPDF({ orientation: 'portrait', unit: 'mm', format: 'a4' })

  const W = 210
  const margin = 20

  // ── Header bar
  doc.setFillColor(26, 18, 8)
  doc.rect(0, 0, W, 38, 'F')

  doc.setFont('helvetica', 'bold')
  doc.setFontSize(9)
  doc.setTextColor(180, 140, 50)
  doc.text('TRADUCERE AUTORIZATĂ / תרגום מאושר', W / 2, 10, { align: 'center' })

  doc.setFontSize(16)
  doc.setTextColor(255, 255, 255)
  doc.text(result.documentType?.toUpperCase() || 'DOCUMENT OFICIAL', W / 2, 22, { align: 'center' })

  doc.setFontSize(8)
  doc.setTextColor(180, 140, 50)
  doc.text('STAT ISRAEL  →  ROMÂNIA', W / 2, 32, { align: 'center' })

  // ── Gold rule
  doc.setDrawColor(180, 140, 50)
  doc.setLineWidth(0.5)
  doc.line(margin, 42, W - margin, 42)

  let y = 50

  // ── Certification block
  doc.setFont('helvetica', 'italic')
  doc.setFontSize(9)
  doc.setTextColor(60, 45, 15)

  const certText = NOTARIAL_CERTIFICATION(result.documentType, translatorName, date)
  const certLines = doc.splitTextToSize(certText, W - margin * 2 - 8)

  doc.setDrawColor(180, 140, 50)
  doc.setLineWidth(0.8)
  doc.line(margin, y, margin, y + certLines.length * 5 + 8)

  doc.text(certLines, margin + 6, y + 4)
  y += certLines.length * 5 + 16

  // ── Fields table
  if (result.fields && result.fields.length > 0) {
    doc.setFont('helvetica', 'bold')
    doc.setFontSize(7.5)
    doc.setTextColor(120, 90, 20)
    doc.text('DATE DIN DOCUMENT / פרטי המסמך', margin, y)
    y += 6

    autoTable(doc, {
      startY: y,
      margin: { left: margin, right: margin },
      head: [['Câmp / שדה', 'Original (עברית)', 'Traducere (Română)']],
      body: result.fields.map((f) => [f.labelRo || '', f.valueOriginal || '', f.valueRo || '']),
      styles: {
        font: 'helvetica',
        fontSize: 8.5,
        cellPadding: 3,
        textColor: [26, 18, 8],
        lineColor: [212, 188, 122],
        lineWidth: 0.3,
      },
      headStyles: {
        fillColor: [42, 31, 10],
        textColor: [212, 188, 122],
        fontStyle: 'bold',
        fontSize: 8,
      },
      alternateRowStyles: { fillColor: [253, 248, 237] },
      columnStyles: {
        0: { cellWidth: 50, fontStyle: 'bold' },
        1: { cellWidth: 55, font: 'helvetica' },
        2: { cellWidth: 'auto' },
      },
    })

    y = doc.lastAutoTable.finalY + 12
  }

  // ── Full translation
  if (result.fullTranslation) {
    if (y > 230) { doc.addPage(); y = 20 }

    doc.setFont('helvetica', 'bold')
    doc.setFontSize(8)
    doc.setTextColor(120, 90, 20)
    doc.text('TRADUCEREA INTEGRALĂ A DOCUMENTULUI', margin, y)
    y += 2

    doc.setDrawColor(212, 188, 122)
    doc.setLineWidth(0.4)
    doc.line(margin, y + 2, W - margin, y + 2)
    y += 8

    doc.setFont('helvetica', 'normal')
    doc.setFontSize(9.5)
    doc.setTextColor(26, 18, 8)
    const transLines = doc.splitTextToSize(result.fullTranslation, W - margin * 2)
    for (const line of transLines) {
      if (y > 270) { doc.addPage(); y = 20 }
      doc.text(line, margin, y)
      y += 5.5
    }
    y += 10
  }

  // ── Translator notes
  if (result.notes) {
    if (y > 240) { doc.addPage(); y = 20 }
    doc.setFont('helvetica', 'italic')
    doc.setFontSize(8)
    doc.setTextColor(100, 75, 20)
    doc.text('Nota traducătorului: ' + result.notes, margin, y, { maxWidth: W - margin * 2 })
    y += 12
  }

  // ── Signatures
  if (y > 220) { doc.addPage(); y = 20 }

  doc.setDrawColor(26, 18, 8)
  doc.setLineWidth(0.4)
  doc.line(margin, y, W - margin, y)
  y += 10

  // Translator signature
  doc.setFont('helvetica', 'bold')
  doc.setFontSize(7.5)
  doc.setTextColor(120, 90, 20)
  doc.text('TRADUCĂTOR AUTORIZAT', margin, y)
  doc.text('NOTAR PUBLIC', W / 2 + 5, y)

  y += 18
  doc.setDrawColor(26, 18, 8)
  doc.line(margin, y, margin + 70, y)
  doc.line(W / 2 + 5, y, W - margin, y)

  y += 5
  doc.setFont('helvetica', 'normal')
  doc.setFontSize(8)
  doc.setTextColor(80, 60, 20)
  doc.text(translatorName || 'Semnătura / חתימה', margin, y)
  doc.text('Semnătura și ștampila', W / 2 + 5, y)

  y += 6
  doc.text(`Data: ${date || new Date().toLocaleDateString('ro-RO')}`, margin, y)
  doc.text('Data: ___________________', W / 2 + 5, y)

  // ── Notary block
  y += 16
  if (y > 240) { doc.addPage(); y = 20 }

  doc.setFillColor(253, 248, 237)
  doc.setDrawColor(180, 140, 50)
  doc.setLineWidth(0.5)
  doc.rect(margin, y, W - margin * 2, 55, 'FD')

  doc.setFont('helvetica', 'bold')
  doc.setFontSize(7.5)
  doc.setTextColor(120, 90, 20)
  doc.text('APOSTILĂ / LEGALIZARE NOTARIALĂ', W / 2, y + 8, { align: 'center' })

  doc.setFont('helvetica', 'normal')
  doc.setFontSize(8.5)
  doc.setTextColor(26, 18, 8)
  const notaryLines = doc.splitTextToSize(
    'Eu, notarul public _________________________________, certific autenticitatea semnăturii traducătorului autorizat și confirm că acesta/aceasta este autorizat/ă să efectueze traduceri din ebraică în română.\n\nLocul legalizării: _________________ Data: ___________ Nr.: __________',
    W - margin * 2 - 16
  )
  doc.text(notaryLines, W / 2, y + 18, { align: 'center' })

  // ── Footer
  const pageCount = doc.internal.getNumberOfPages()
  for (let i = 1; i <= pageCount; i++) {
    doc.setPage(i)
    doc.setFillColor(26, 18, 8)
    doc.rect(0, 287, W, 10, 'F')
    doc.setFont('helvetica', 'normal')
    doc.setFontSize(6.5)
    doc.setTextColor(180, 140, 50)
    doc.text(
      `Traducere autorizată ebraică–română  |  Pagina ${i} din ${pageCount}  |  ${new Date().toLocaleDateString('ro-RO')}`,
      W / 2,
      293,
      { align: 'center' }
    )
  }

  doc.save(`traducere-notariala-${Date.now()}.pdf`)
}

// ─── DOCX Export ──────────────────────────────────────────────────────────────

export async function exportToDOCX(result, translatorName, date) {
  const goldColor = 'B89228'
  const inkColor = '1A1208'
  const creamColor = 'FDF8ED'

  const border = {
    top: { style: BorderStyle.SINGLE, size: 6, color: goldColor },
    bottom: { style: BorderStyle.SINGLE, size: 6, color: goldColor },
    left: { style: BorderStyle.SINGLE, size: 6, color: goldColor },
    right: { style: BorderStyle.SINGLE, size: 6, color: goldColor },
  }

  const thinBorder = {
    top: { style: BorderStyle.SINGLE, size: 2, color: 'D4BC7A' },
    bottom: { style: BorderStyle.SINGLE, size: 2, color: 'D4BC7A' },
    left: { style: BorderStyle.SINGLE, size: 2, color: 'D4BC7A' },
    right: { style: BorderStyle.SINGLE, size: 2, color: 'D4BC7A' },
  }

  const paragraphs = []

  // ── Title section
  paragraphs.push(
    new Paragraph({
      alignment: AlignmentType.CENTER,
      spacing: { before: 0, after: 120 },
      children: [
        new TextRun({
          text: 'TRADUCERE AUTORIZATĂ',
          bold: true,
          size: 16,
          color: goldColor,
          font: 'Libre Baskerville',
        }),
      ],
    }),
    new Paragraph({
      alignment: AlignmentType.CENTER,
      spacing: { before: 0, after: 80 },
      children: [
        new TextRun({
          text: (result.documentType || 'DOCUMENT OFICIAL').toUpperCase(),
          bold: true,
          size: 28,
          color: inkColor,
          font: 'Libre Baskerville',
        }),
      ],
    }),
    new Paragraph({
      alignment: AlignmentType.CENTER,
      spacing: { before: 0, after: 360 },
      border: { bottom: { style: BorderStyle.SINGLE, size: 6, color: goldColor } },
      children: [
        new TextRun({
          text: 'STAT ISRAEL  →  ROMÂNIA',
          size: 18,
          color: goldColor,
          font: 'Crimson Pro',
          italics: true,
        }),
      ],
    })
  )

  // ── Certification
  const certText = NOTARIAL_CERTIFICATION(result.documentType, translatorName, date)
  paragraphs.push(
    new Paragraph({
      spacing: { before: 240, after: 120 },
      border: { left: { style: BorderStyle.SINGLE, size: 12, color: goldColor } },
      indent: { left: 360 },
      children: [
        new TextRun({
          text: certText,
          italics: true,
          size: 20,
          color: '3A2D10',
          font: 'Crimson Pro',
        }),
      ],
    })
  )

  // ── Fields table
  if (result.fields && result.fields.length > 0) {
    paragraphs.push(
      new Paragraph({
        spacing: { before: 360, after: 160 },
        children: [
          new TextRun({
            text: 'DATE DIN DOCUMENT / פרטי המסמך',
            bold: true,
            size: 16,
            color: goldColor,
            font: 'Libre Baskerville',
            allCaps: true,
          }),
        ],
      })
    )

    const headerRow = new TableRow({
      tableHeader: true,
      children: ['Câmp / שדה', 'Original (עברית)', 'Traducere (Română)'].map(
        (h) =>
          new TableCell({
            shading: { type: ShadingType.SOLID, color: '2A1F0A' },
            borders: thinBorder,
            children: [
              new Paragraph({
                alignment: AlignmentType.CENTER,
                children: [
                  new TextRun({ text: h, bold: true, color: 'D4BC7A', size: 17, font: 'Libre Baskerville' }),
                ],
              }),
            ],
          })
      ),
    })

    const dataRows = result.fields.map(
      (f) =>
        new TableRow({
          children: [
            new TableCell({
              borders: thinBorder,
              shading: { type: ShadingType.SOLID, color: 'F5EEC8' },
              children: [new Paragraph({ children: [new TextRun({ text: f.labelRo || '', bold: true, size: 18, font: 'Libre Baskerville', color: inkColor })] })],
            }),
            new TableCell({
              borders: thinBorder,
              children: [new Paragraph({ children: [new TextRun({ text: f.valueOriginal || '', size: 19, font: 'Frank Ruhl Libre', color: inkColor })] })],
            }),
            new TableCell({
              borders: thinBorder,
              children: [new Paragraph({ children: [new TextRun({ text: f.valueRo || '', size: 19, font: 'Crimson Pro', color: inkColor })] })],
            }),
          ],
        })
    )

    paragraphs.push(
      new Table({
        width: { size: 100, type: WidthType.PERCENTAGE },
        borders: border,
        rows: [headerRow, ...dataRows],
      })
    )
  }

  // ── Full translation
  if (result.fullTranslation) {
    paragraphs.push(
      new Paragraph({
        spacing: { before: 480, after: 160 },
        border: { bottom: { style: BorderStyle.SINGLE, size: 4, color: 'D4BC7A' } },
        children: [
          new TextRun({
            text: 'TRADUCEREA INTEGRALĂ A DOCUMENTULUI',
            bold: true,
            size: 18,
            color: goldColor,
            font: 'Libre Baskerville',
            allCaps: true,
          }),
        ],
      }),
      new Paragraph({
        spacing: { before: 120, after: 480 },
        children: [
          new TextRun({
            text: result.fullTranslation,
            size: 22,
            font: 'Crimson Pro',
            color: inkColor,
          }),
        ],
      })
    )
  }

  // ── Notes
  if (result.notes) {
    paragraphs.push(
      new Paragraph({
        spacing: { before: 120, after: 360 },
        children: [
          new TextRun({ text: 'Nota traducătorului: ', italics: true, bold: true, size: 18, color: goldColor, font: 'Crimson Pro' }),
          new TextRun({ text: result.notes, italics: true, size: 18, color: '5A4520', font: 'Crimson Pro' }),
        ],
      })
    )
  }

  // ── Signature table
  paragraphs.push(
    new Paragraph({
      spacing: { before: 480, after: 0 },
      border: { top: { style: BorderStyle.SINGLE, size: 8, color: inkColor } },
      children: [],
    }),
    new Table({
      width: { size: 100, type: WidthType.PERCENTAGE },
      borders: {
        top: { style: BorderStyle.NONE },
        bottom: { style: BorderStyle.NONE },
        left: { style: BorderStyle.NONE },
        right: { style: BorderStyle.NONE },
        insideH: { style: BorderStyle.NONE },
        insideV: { style: BorderStyle.NONE },
      },
      rows: [
        new TableRow({
          children: [
            new TableCell({
              width: { size: 50, type: WidthType.PERCENTAGE },
              children: [
                new Paragraph({ children: [new TextRun({ text: 'TRADUCĂTOR AUTORIZAT', bold: true, size: 16, color: goldColor, font: 'Libre Baskerville', allCaps: true })] }),
                new Paragraph({ spacing: { before: 480 }, border: { bottom: { style: BorderStyle.SINGLE, size: 4, color: inkColor } }, children: [] }),
                new Paragraph({ children: [new TextRun({ text: translatorName || 'Semnătura', size: 18, font: 'Crimson Pro', color: inkColor })] }),
                new Paragraph({ children: [new TextRun({ text: `Data: ${date || new Date().toLocaleDateString('ro-RO')}`, size: 18, font: 'Crimson Pro', color: inkColor })] }),
              ],
            }),
            new TableCell({
              width: { size: 50, type: WidthType.PERCENTAGE },
              children: [
                new Paragraph({ alignment: AlignmentType.LEFT, children: [new TextRun({ text: 'NOTAR PUBLIC', bold: true, size: 16, color: goldColor, font: 'Libre Baskerville', allCaps: true })] }),
                new Paragraph({ spacing: { before: 480 }, border: { bottom: { style: BorderStyle.SINGLE, size: 4, color: inkColor } }, children: [] }),
                new Paragraph({ children: [new TextRun({ text: 'Semnătura și ștampila', size: 18, font: 'Crimson Pro', color: '888888' })] }),
                new Paragraph({ children: [new TextRun({ text: 'Data: ___________________', size: 18, font: 'Crimson Pro', color: '888888' })] }),
              ],
            }),
          ],
        }),
      ],
    })
  )

  // ── Notary apostille box
  paragraphs.push(
    new Paragraph({ spacing: { before: 480 }, children: [] }),
    new Table({
      width: { size: 100, type: WidthType.PERCENTAGE },
      borders: border,
      rows: [
        new TableRow({
          children: [
            new TableCell({
              shading: { type: ShadingType.SOLID, color: 'FDF8ED' },
              margins: { top: 160, bottom: 160, left: 240, right: 240 },
              children: [
                new Paragraph({
                  alignment: AlignmentType.CENTER,
                  spacing: { after: 160 },
                  children: [new TextRun({ text: 'APOSTILĂ / LEGALIZARE NOTARIALĂ', bold: true, size: 18, color: goldColor, font: 'Libre Baskerville', allCaps: true })],
                }),
                new Paragraph({
                  children: [new TextRun({ text: NOTARY_BLOCK, size: 19, font: 'Crimson Pro', color: inkColor })],
                }),
              ],
            }),
          ],
        }),
      ],
    })
  )

  const docx = new Document({
    styles: {
      default: {
        document: {
          run: { font: 'Crimson Pro', size: 22, color: inkColor },
          paragraph: { spacing: { line: 276 } },
        },
      },
    },
    sections: [
      {
        properties: {
          page: {
            margin: { top: 1440, bottom: 1440, left: 1800, right: 1800 },
          },
        },
        children: paragraphs,
      },
    ],
  })

  const buffer = await Packer.toBlob(docx)
  const url = URL.createObjectURL(buffer)
  const a = document.createElement('a')
  a.href = url
  a.download = `traducere-notariala-${Date.now()}.docx`
  a.click()
  URL.revokeObjectURL(url)
}
