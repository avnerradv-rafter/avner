import { useState, useRef, useCallback } from 'react'
import { processFile } from './ocr.js'
import { translateWithClaude } from './translate.js'
import { exportToPDF, exportToDOCX } from './export.js'
import { DOCUMENT_TYPES } from './constants.js'
import './App.css'

const STEPS = ['העלאה', 'זיהוי', 'תרגום', 'פלט']

export default function App() {
  const [apiKey, setApiKey] = useState(() => localStorage.getItem('nt_api_key') || '')
  const [showApiKey, setShowApiKey] = useState(false)
  const [file, setFile] = useState(null)
  const [preview, setPreview] = useState(null)
  const [ocrText, setOcrText] = useState('')
  const [ocrProgress, setOcrProgress] = useState(0)
  const [result, setResult] = useState(null)
  const [translatorName, setTranslatorName] = useState('')
  const [translationDate, setTranslationDate] = useState(
    new Date().toLocaleDateString('ro-RO')
  )
  const [step, setStep] = useState(0) // 0=upload, 1=ocr, 2=translate, 3=output
  const [loading, setLoading] = useState(false)
  const [loadingMsg, setLoadingMsg] = useState('')
  const [error, setError] = useState('')
  const [cameraOpen, setCameraOpen] = useState(false)
  const [editingOcr, setEditingOcr] = useState(false)

  const fileRef = useRef()
  const videoRef = useRef()
  const streamRef = useRef()
  const dropRef = useRef()

  const saveApiKey = (k) => {
    setApiKey(k)
    localStorage.setItem('nt_api_key', k)
  }

  // ── File handling ──────────────────────────────────────────────────────────
  const handleFile = useCallback((f) => {
    if (!f) return
    setFile(f)
    setError('')
    setResult(null)
    setOcrText('')
    setStep(1)

    if (f.type.startsWith('image/')) {
      const reader = new FileReader()
      reader.onload = (e) => setPreview(e.target.result)
      reader.readAsDataURL(f)
    } else {
      setPreview(null)
    }
  }, [])

  const handleDrop = useCallback(
    (e) => {
      e.preventDefault()
      dropRef.current?.classList.remove('drag-over')
      const f = e.dataTransfer.files[0]
      if (f) handleFile(f)
    },
    [handleFile]
  )

  // ── Camera ─────────────────────────────────────────────────────────────────
  const openCamera = async () => {
    try {
      const stream = await navigator.mediaDevices.getUserMedia({
        video: { facingMode: 'environment', width: { ideal: 1920 }, height: { ideal: 1080 } },
      })
      streamRef.current = stream
      setCameraOpen(true)
      setTimeout(() => {
        if (videoRef.current) videoRef.current.srcObject = stream
      }, 100)
    } catch {
      setError('לא ניתן לגשת למצלמה — אנא בדוק הרשאות')
    }
  }

  const capturePhoto = () => {
    const video = videoRef.current
    if (!video) return
    const canvas = document.createElement('canvas')
    canvas.width = video.videoWidth
    canvas.height = video.videoHeight
    canvas.getContext('2d').drawImage(video, 0, 0)
    canvas.toBlob((blob) => {
      const f = new File([blob], 'scan.jpg', { type: 'image/jpeg' })
      setPreview(canvas.toDataURL('image/jpeg'))
      handleFile(f)
      closeCamera()
    }, 'image/jpeg', 0.95)
  }

  const closeCamera = () => {
    streamRef.current?.getTracks().forEach((t) => t.stop())
    setCameraOpen(false)
  }

  // ── OCR ────────────────────────────────────────────────────────────────────
  const runOCR = async () => {
    if (!file) return
    setLoading(true)
    setError('')
    setLoadingMsg('מאתחל מנוע זיהוי תווים (OCR)...')
    setOcrProgress(0)

    try {
      const text = await processFile(file, (p) => {
        setOcrProgress(p)
        setLoadingMsg(`מזהה טקסט עברי... ${p}%`)
      })
      setOcrText(text)
      setStep(2)
    } catch (e) {
      setError(e.message)
    } finally {
      setLoading(false)
      setLoadingMsg('')
    }
  }

  // ── Translation ────────────────────────────────────────────────────────────
  const runTranslation = async () => {
    if (!ocrText.trim()) return setError('אין טקסט לתרגום')
    if (!apiKey) return setError('נדרש מפתח Anthropic API')

    setLoading(true)
    setError('')
    setLoadingMsg('שולח לתרגום נוטריוני... (עשוי לקחת עד 30 שניות)')

    try {
      const r = await translateWithClaude(ocrText, apiKey)
      setResult(r)
      setStep(3)
    } catch (e) {
      setError(e.message)
    } finally {
      setLoading(false)
      setLoadingMsg('')
    }
  }

  // ── Export ─────────────────────────────────────────────────────────────────
  const handleExport = async (format) => {
    if (!result) return
    setLoading(true)
    setLoadingMsg(`מייצא כ-${format.toUpperCase()}...`)
    try {
      if (format === 'pdf') await exportToPDF(result, translatorName, translationDate)
      else await exportToDOCX(result, translatorName, translationDate)
    } catch (e) {
      setError('שגיאה בייצוא: ' + e.message)
    } finally {
      setLoading(false)
      setLoadingMsg('')
    }
  }

  const reset = () => {
    setFile(null); setPreview(null); setOcrText(''); setResult(null)
    setStep(0); setError(''); setOcrProgress(0)
  }

  // ── Render ─────────────────────────────────────────────────────────────────
  return (
    <div className="app">
      {/* Camera overlay */}
      {cameraOpen && (
        <div className="camera-overlay">
          <video ref={videoRef} autoPlay playsInline className="camera-video" />
          <div className="camera-controls">
            <button className="btn-capture" onClick={capturePhoto}>📷 צלם</button>
            <button className="btn-cancel-cam" onClick={closeCamera}>ביטול</button>
          </div>
          <div className="camera-frame" />
        </div>
      )}

      {/* Header */}
      <header className="app-header">
        <div className="header-inner">
          <div className="header-seal">⚖</div>
          <div className="header-text">
            <h1>מתרגם נוטריוני</h1>
            <p>Traducător Notarial Autorizat — עברית ⟶ רומנית</p>
          </div>
          <button className="api-btn" onClick={() => setShowApiKey((v) => !v)} title="הגדרות API">
            ⚙
          </button>
        </div>
        {showApiKey && (
          <div className="api-panel">
            <label>מפתח Anthropic API</label>
            <div className="api-input-row">
              <input
                type="password"
                value={apiKey}
                onChange={(e) => saveApiKey(e.target.value)}
                placeholder="sk-ant-..."
                className="api-input"
              />
              <a href="https://console.anthropic.com/keys" target="_blank" rel="noreferrer" className="api-link">
                קבל מפתח ↗
              </a>
            </div>
            <p className="api-note">המפתח נשמר מקומית בדפדפן בלבד ואינו נשלח לשרת כלשהו.</p>
          </div>
        )}
      </header>

      {/* Progress steps */}
      <nav className="steps-nav">
        {STEPS.map((s, i) => (
          <div key={s} className={`step-item ${i === step ? 'active' : ''} ${i < step ? 'done' : ''}`}>
            <div className="step-dot">{i < step ? '✓' : i + 1}</div>
            <span>{s}</span>
            {i < STEPS.length - 1 && <div className="step-line" />}
          </div>
        ))}
      </nav>

      <main className="app-main">
        {error && (
          <div className="error-banner">
            <span>⚠ {error}</span>
            <button onClick={() => setError('')}>×</button>
          </div>
        )}

        {loading && (
          <div className="loading-overlay">
            <div className="loading-spinner" />
            <p>{loadingMsg}</p>
            {ocrProgress > 0 && ocrProgress < 100 && (
              <div className="progress-bar">
                <div className="progress-fill" style={{ width: `${ocrProgress}%` }} />
              </div>
            )}
          </div>
        )}

        {/* ── STEP 0: Upload ── */}
        {step === 0 && (
          <div className="panel">
            <h2 className="panel-title">העלאת מסמך לתרגום נוטריוני</h2>
            <p className="panel-sub">
              תומך ב: תעודת לידה, תעודת אזרחות, תמצית רישום אוכלוסין, תעודת נישואין,
              תעודת גירושין, תעודת פטירה, דרכון, תעודת זהות ומסמכים נוספים.
            </p>

            <div
              ref={dropRef}
              className="drop-zone"
              onClick={() => fileRef.current?.click()}
              onDrop={handleDrop}
              onDragOver={(e) => { e.preventDefault(); dropRef.current?.classList.add('drag-over') }}
              onDragLeave={() => dropRef.current?.classList.remove('drag-over')}
            >
              <div className="drop-icon">📄</div>
              <div className="drop-label">גרור קובץ לכאן או לחץ לבחירה</div>
              <div className="drop-sub">JPG, PNG, PDF · עד 20MB</div>
              <input
                ref={fileRef}
                type="file"
                accept="image/*,.pdf"
                style={{ display: 'none' }}
                onChange={(e) => handleFile(e.target.files[0])}
              />
            </div>

            <div className="or-divider"><span>או</span></div>

            <button className="btn-camera" onClick={openCamera}>
              📷 צילום מסמך בזמן אמת
            </button>
          </div>
        )}

        {/* ── STEP 1: OCR ── */}
        {step === 1 && (
          <div className="panel">
            <h2 className="panel-title">זיהוי טקסט עברי (OCR)</h2>

            <div className="file-info-bar">
              <span className="file-icon">{file?.type === 'application/pdf' ? '📋' : '🖼'}</span>
              <span className="file-name">{file?.name}</span>
              <span className="file-size">{file ? (file.size / 1024).toFixed(0) + ' KB' : ''}</span>
              <button className="btn-ghost" onClick={reset}>החלף</button>
            </div>

            {preview && (
              <div className="preview-container">
                <img src={preview} alt="תצוגה מקדימה" className="preview-img" />
              </div>
            )}

            {!preview && file?.type === 'application/pdf' && (
              <div className="pdf-placeholder">📋 PDF — יעובד בזמן הסריקה</div>
            )}

            <button className="btn-primary" onClick={runOCR} disabled={loading}>
              {loading ? `מזהה... ${ocrProgress}%` : '▶ התחל זיהוי OCR'}
            </button>
          </div>
        )}

        {/* ── STEP 2: Translate ── */}
        {step === 2 && (
          <div className="panel">
            <h2 className="panel-title">תרגום נוטריוני לרומנית</h2>

            <div className="ocr-result-box">
              <div className="ocr-result-header">
                <span>טקסט שזוהה על ידי OCR</span>
                <button className="btn-ghost" onClick={() => setEditingOcr((v) => !v)}>
                  {editingOcr ? '✓ שמור' : '✏ ערוך'}
                </button>
              </div>
              {editingOcr ? (
                <textarea
                  className="ocr-textarea"
                  value={ocrText}
                  onChange={(e) => setOcrText(e.target.value)}
                  rows={10}
                />
              ) : (
                <div className="ocr-text-display">{ocrText}</div>
              )}
            </div>

            <div className="translator-meta">
              <div className="meta-field">
                <label>שם המתרגם/ת המורשה</label>
                <input
                  type="text"
                  value={translatorName}
                  onChange={(e) => setTranslatorName(e.target.value)}
                  placeholder="Numele traducătorului autorizat"
                  className="meta-input"
                />
              </div>
              <div className="meta-field">
                <label>תאריך התרגום</label>
                <input
                  type="text"
                  value={translationDate}
                  onChange={(e) => setTranslationDate(e.target.value)}
                  className="meta-input"
                />
              </div>
            </div>

            {!apiKey && (
              <div className="api-warning">
                ⚠ נדרש מפתח Anthropic API — לחץ על ⚙ בפינה הימנית העליונה להזנת המפתח
              </div>
            )}

            <div className="btn-row">
              <button className="btn-secondary" onClick={() => setStep(1)}>← חזרה</button>
              <button className="btn-primary" onClick={runTranslation} disabled={loading || !apiKey}>
                {loading ? 'מתרגם...' : '▶ תרגם נוטריונית'}
              </button>
            </div>
          </div>
        )}

        {/* ── STEP 3: Output ── */}
        {step === 3 && result && (
          <div className="panel panel-wide">
            <h2 className="panel-title">תרגום נוטריוני — מוכן לאישור</h2>

            {/* Document type badge */}
            <div className="doc-type-badge">
              <span className="badge-he">{DOCUMENT_TYPES[result.documentTypeKey]?.he || result.documentType}</span>
              <span className="badge-arrow">⟶</span>
              <span className="badge-ro">{result.documentType}</span>
            </div>

            {/* Certification block */}
            <div className="cert-block">
              <div className="cert-label">הצהרת מתרגם מאושר</div>
              <p className="cert-text" lang="ro">
                Subsemnatul/a <strong>{translatorName || '___________________________'}</strong>,
                traducător autorizat din limba ebraică în limba română, certific că prezenta traducere
                a documentului intitulat „<em>{result.documentType}</em>", emis de autoritățile
                competente ale Statului Israel, este conformă și fidelă cu originalul.
              </p>
            </div>

            {/* Fields table */}
            {result.fields && result.fields.length > 0 && (
              <div className="fields-section">
                <div className="section-label">DATE DIN DOCUMENT / פרטי המסמך</div>
                <table className="fields-table">
                  <thead>
                    <tr>
                      <th>Câmp / שדה</th>
                      <th>Original (עברית)</th>
                      <th>Traducere (Română)</th>
                    </tr>
                  </thead>
                  <tbody>
                    {result.fields.map((f, i) => (
                      <tr key={i}>
                        <td className="field-label-cell">{f.labelRo}</td>
                        <td className="field-orig-cell" dir="rtl">{f.valueOriginal}</td>
                        <td className="field-trans-cell" lang="ro">{f.valueRo}</td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            )}

            {/* Full translation */}
            <div className="translation-section">
              <div className="section-label">TRADUCEREA INTEGRALĂ / תרגום מלא</div>
              <div className="translation-text" lang="ro">{result.fullTranslation}</div>
            </div>

            {/* Notes */}
            {result.notes && (
              <div className="notes-block">
                <strong>Nota traducătorului:</strong> {result.notes}
              </div>
            )}

            {/* Notary block */}
            <div className="notary-block">
              <div className="notary-header">APOSTILĂ / LEGALIZARE NOTARIALĂ</div>
              <div className="notary-grid">
                <div className="sig-col">
                  <div className="sig-role">TRADUCĂTOR AUTORIZAT</div>
                  <div className="sig-name">{translatorName || '______________________________'}</div>
                  <div className="sig-line-el" />
                  <div className="sig-date">Data: {translationDate}</div>
                </div>
                <div className="sig-col">
                  <div className="sig-role">NOTAR PUBLIC</div>
                  <div className="sig-name" style={{ color: '#aaa' }}>______________________________</div>
                  <div className="sig-line-el" />
                  <div className="sig-date" style={{ color: '#aaa' }}>Data: ___________________  Nr.: _______</div>
                </div>
              </div>
            </div>

            {/* Export buttons */}
            <div className="export-section">
              <div className="export-label">הורדת המסמך הנוטריוני</div>
              <div className="export-buttons">
                <button className="btn-export pdf" onClick={() => handleExport('pdf')}>
                  <span className="export-icon">📄</span>
                  <span className="export-text">
                    <strong>PDF</strong>
                    <small>להדפסה ולהגשה</small>
                  </span>
                </button>
                <button className="btn-export docx" onClick={() => handleExport('docx')}>
                  <span className="export-icon">📝</span>
                  <span className="export-text">
                    <strong>Word (DOCX)</strong>
                    <small>לעריכה נוספת</small>
                  </span>
                </button>
                <button className="btn-export print" onClick={() => window.print()}>
                  <span className="export-icon">🖨</span>
                  <span className="export-text">
                    <strong>הדפסה</strong>
                    <small>ישיר לנוטריון</small>
                  </span>
                </button>
              </div>
            </div>

            <div className="btn-row" style={{ marginTop: 24 }}>
              <button className="btn-secondary" onClick={() => setStep(2)}>← ערוך תרגום</button>
              <button className="btn-ghost-dark" onClick={reset}>+ מסמך חדש</button>
            </div>
          </div>
        )}
      </main>

      <footer className="app-footer">
        <p>כלי תרגום נוטריוני מעברית לרומנית · Traducător Notarial Ebraică–Română</p>
        <p className="footer-sub">מסמכי הפלט מיועדים לאישור נוטריון מוסמך בלבד</p>
      </footer>
    </div>
  )
}
