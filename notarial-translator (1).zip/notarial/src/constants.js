// ─── Document type definitions ────────────────────────────────────────────────

export const DOCUMENT_TYPES = {
  birth:       { he: 'תעודת לידה',             ro: 'Certificat de Naștere' },
  citizenship: { he: 'תעודת אזרחות',           ro: 'Certificat de Cetățenie' },
  population:  { he: 'תמצית רישום אוכלוסין',   ro: 'Extras din Registrul de Populație' },
  marriage:    { he: 'תעודת נישואין',           ro: 'Certificat de Căsătorie' },
  divorce:     { he: 'תעודת גירושין',           ro: 'Certificat de Divorț' },
  death:       { he: 'תעודת פטירה',             ro: 'Certificat de Deces' },
  passport:    { he: 'דרכון',                   ro: 'Pașaport' },
  id:          { he: 'תעודת זהות',              ro: 'Buletin de Identitate' },
  other:       { he: 'מסמך אחר',                ro: 'Alt Document Oficial' },
}

// ─── System prompt for Claude ─────────────────────────────────────────────────

export const SYSTEM_PROMPT = `Ești un traducător juridic autorizat specializat în traduceri din limba ebraică în limba română, destinată uz notarial.

Rolul tău:
1. Primești text în ebraică extras prin OCR dintr-un document oficial israelian.
2. Identifici tipul documentului (certificat de naștere, cetățenie, extras de populație etc.).
3. Produci o traducere completă, fidelă, în limbaj juridic formal românesc, adecvată legalizării notariale.

Reguli stricte:
- Traducerea trebuie să fie completă și fidelă originalului, fără omisiuni.
- Folosește terminologia juridică română standardizată.
- Păstrează toate datele, numerele, denumirile proprii și datele de identificare exact ca în original (nu traduce nume proprii, doar transliterează dacă este necesar).
- Datele calendaristice: convertește din format israelian/ebraic în format dd.mm.yyyy.
- Dacă textul OCR conține erori evidente, corectează-le pe baza contextului documentului.
- Identifică și structurează câmpurile documentului (Prenume, Nume, Data nașterii etc.).

Format de răspuns — returnează EXCLUSIV un obiect JSON valid, fără explicații, fără markdown, fără text în afara JSON-ului:
{
  "documentType": "tipul documentului în română",
  "documentTypeKey": "cheia tipului (birth/citizenship/population/marriage/divorce/death/passport/id/other)",
  "originalText": "textul ebraic original curățat",
  "fields": [
    { "labelRo": "Numele și prenumele", "labelHe": "שם מלא", "valueOriginal": "ערך בעברית", "valueRo": "Valoarea tradusă" }
  ],
  "fullTranslation": "Traducerea completă a întregului document în română, în formă narativă-juridică formală, gata pentru inserare în actul notarial.",
  "notes": "Observații ale traducătorului (dacă există — lizibilitate scăzută, câmpuri lipsă etc.) sau șir gol."
}`

// ─── Notarial certification text ──────────────────────────────────────────────

export const NOTARIAL_CERTIFICATION = (docTypeRo, translatorName, date) => `
Subsemnatul/a ${translatorName || '___________________________'}, traducător autorizat din limba ebraică în limba română, autorizat de Ministerul Justiției al României, certific că prezenta traducere a documentului intitulat „${docTypeRo}", emis de autoritățile competente ale Statului Israel, este conformă și fidelă cu originalul care mi-a fost prezentat spre traducere.

Prezenta traducere a fost efectuată cu respectarea deplină a normelor legale în vigoare privind traducerile autorizate și este destinată prezentării în fața autorităților notariale române.

Data: ${date || '___________________________'}
`.trim()

export const NOTARY_BLOCK = `
─────────────────────────────────────────────────────────
APOSTILĂ / LEGALIZARE NOTARIALĂ

Eu, notarul public _________________________________,
certific autenticitatea semnăturii traducătorului autorizat
dl./dna. _____________________________, și confirm că
acesta/aceasta este autorizat/ă să efectueze traduceri
din limba ebraică în limba română.

Locul legalizării: _______________________________
Data: _______________ Nr. de înregistrare: _________

Semnătura și ștampila notarului: 


_________________________________
─────────────────────────────────────────────────────────
`.trim()
