import { createWorker } from 'tesseract.js'

let worker = null
let workerReady = false

async function getWorker(onProgress) {
  if (worker && workerReady) return worker

  worker = await createWorker('heb+eng', 1, {
    logger: (m) => {
      if (m.status === 'recognizing text' && onProgress) {
        onProgress(Math.round(m.progress * 100))
      }
    },
  })

  await worker.setParameters({
    tessedit_char_whitelist: '',
    preserve_interword_spaces: '1',
  })

  workerReady = true
  return worker
}

export async function extractTextFromImage(imageSource, onProgress) {
  const w = await getWorker(onProgress)
  const result = await w.recognize(imageSource)
  return result.data.text
}

export async function extractTextFromPDF(pdfFile, onProgress) {
  // Convert first page of PDF to image via canvas, then OCR
  const { getDocument, GlobalWorkerOptions } = await import('pdfjs-dist')

  // Use CDN worker for pdfjs
  GlobalWorkerOptions.workerSrc =
    'https://cdnjs.cloudflare.com/ajax/libs/pdf.js/3.11.174/pdf.worker.min.js'

  const arrayBuffer = await pdfFile.arrayBuffer()
  const pdf = await getDocument({ data: arrayBuffer }).promise

  const allText = []

  for (let pageNum = 1; pageNum <= pdf.numPages; pageNum++) {
    const page = await pdf.getPage(pageNum)
    const viewport = page.getViewport({ scale: 2.5 })
    const canvas = document.createElement('canvas')
    canvas.width = viewport.width
    canvas.height = viewport.height
    const ctx = canvas.getContext('2d')
    await page.render({ canvasContext: ctx, viewport }).promise

    const imageDataUrl = canvas.toDataURL('image/png')
    if (onProgress) onProgress(Math.round((pageNum / pdf.numPages) * 80))

    const text = await extractTextFromImage(imageDataUrl, (p) => {
      if (onProgress) onProgress(80 + Math.round((p / 100) * 20))
    })
    allText.push(text)
  }

  return allText.join('\n\n')
}

export async function processFile(file, onProgress) {
  const type = file.type

  if (type === 'application/pdf') {
    return extractTextFromPDF(file, onProgress)
  } else if (type.startsWith('image/')) {
    const url = URL.createObjectURL(file)
    const text = await extractTextFromImage(url, onProgress)
    URL.revokeObjectURL(url)
    return text
  }

  throw new Error('סוג קובץ לא נתמך. אנא העלה תמונה (JPG, PNG) או PDF.')
}
