import { SYSTEM_PROMPT } from './constants.js'

export async function translateWithClaude(hebrewText, apiKey) {
  if (!apiKey) throw new Error('נדרש מפתח API של Anthropic')
  if (!hebrewText || hebrewText.trim().length < 5)
    throw new Error('הטקסט המזוהה קצר מדי — אנא ודא שהמסמך סרוק בבהירות')

  const response = await fetch('https://api.anthropic.com/v1/messages', {
    method: 'POST',
    headers: {
      'Content-Type': 'application/json',
      'x-api-key': apiKey,
      'anthropic-version': '2023-06-01',
      'anthropic-dangerous-direct-browser-access': 'true',
    },
    body: JSON.stringify({
      model: 'claude-opus-4-5',
      max_tokens: 4096,
      system: SYSTEM_PROMPT,
      messages: [
        {
          role: 'user',
          content: `להלן טקסט שחולץ מסריקת OCR של מסמך ישראלי רשמי. אנא תרגם ועבד לפי ההנחיות:\n\n${hebrewText}`,
        },
      ],
    }),
  })

  if (!response.ok) {
    const err = await response.json().catch(() => ({}))
    if (response.status === 401) throw new Error('מפתח API שגוי או לא תקף')
    if (response.status === 429) throw new Error('חריגה ממכסת קריאות API — נסה שוב בעוד רגע')
    throw new Error(err.error?.message || `שגיאת API: ${response.status}`)
  }

  const data = await response.json()
  const raw = data.content?.[0]?.text || ''

  // Strip markdown fences if present
  const cleaned = raw.replace(/^```(?:json)?\s*/i, '').replace(/\s*```\s*$/, '').trim()

  try {
    return JSON.parse(cleaned)
  } catch {
    throw new Error('שגיאה בפענוח תגובת התרגום — אנא נסה שנית')
  }
}
