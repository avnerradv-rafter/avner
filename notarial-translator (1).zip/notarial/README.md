# מתרגם נוטריוני — Traducător Notarial Ebraică–Română

כלי מקצועי לתרגום נוטריוני אוטומטי של מסמכים רשמיים ישראליים מעברית לרומנית.

## תכונות

- **OCR עברי** — זיהוי אוטומטי של טקסט עברי מתמונה או PDF
- **צילום מצלמה** — סריקה ישירה ממצלמת המכשיר
- **תרגום AI** — תרגום נוטריוני מלא באמצעות Claude (Anthropic)
- **פלט מקצועי** — ייצוא ל-PDF ו-DOCX מוכן לאישור נוטריון
- **מסמכים נתמכים**: תעודת לידה, אזרחות, תמצית רישום אוכלוסין, נישואין, גירושין, פטירה, דרכון, תעודת זהות ועוד

---

## הפעלה מקומית

```bash
# התקנת תלויות
npm install

# הרצה בסביבת פיתוח
npm run dev

# בנייה לייצור
npm run build
```

---

## פריסה ל-GitHub Pages

### שלב 1 — צור repository ב-GitHub
1. היכנס ל-[github.com](https://github.com) וצור repository חדש
2. שם מוצע: `notarial-translator`

### שלב 2 — הגדרת GitHub Pages
1. כנס ל-**Settings** → **Pages**
2. תחת **Source** בחר **GitHub Actions**

### שלב 3 — דחיפת הקוד
```bash
git init
git add .
git commit -m "Initial commit — Notarial Translator"
git branch -M main
git remote add origin https://github.com/YOUR_USERNAME/notarial-translator.git
git push -u origin main
```

### שלב 4 — הפעלה
לאחר הדחיפה, ה-Action יפעל אוטומטית.  
הכלי יהיה זמין בכתובת:  
`https://YOUR_USERNAME.github.io/notarial-translator/`

---

## שימוש בכלי

1. **לחץ על ⚙** בפינה הימנית העליונה
2. **הזן מפתח Anthropic API** (מ-[console.anthropic.com/keys](https://console.anthropic.com/keys))
3. **העלה מסמך** (תמונה/PDF) או **צלם** ישירות
4. לחץ **התחל זיהוי OCR**
5. ערוך את הטקסט אם נדרש
6. הזן **שם המתרגם** ולחץ **תרגם נוטריונית**
7. הורד את המסמך כ-**PDF** או **DOCX**

> **הערה:** מפתח ה-API נשמר בדפדפן בלבד (`localStorage`) ואינו נשלח לשום שרת חיצוני מלבד Anthropic.

---

## טכנולוגיות

| רכיב | טכנולוגיה |
|------|-----------|
| Framework | React + Vite |
| OCR | Tesseract.js (עברית + אנגלית) |
| תרגום AI | Anthropic Claude API |
| PDF ייצוא | jsPDF + jspdf-autotable |
| DOCX ייצוא | docx.js |
| פריסה | GitHub Pages (via Actions) |

---

## רישיון

לשימוש מקצועי — כל הזכויות שמורות.  
מסמכי הפלט מיועדים לאישור נוטריון מוסמך בלבד.
